import git

git.Git().clone('https://github.com/FlamesLLC/Luckycompiler.git')